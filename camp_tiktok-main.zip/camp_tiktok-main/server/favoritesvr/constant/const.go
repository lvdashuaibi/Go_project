package constant

const (
	SuccessCode = 0
	ErrorCode   = 1
)

const (
	SuccessMsg = "success"
)
